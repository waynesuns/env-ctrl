package com.ec.website.param;

public class DivParam {

}
