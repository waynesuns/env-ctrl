package com.ec.website.util;

public class TableUtils {

}
